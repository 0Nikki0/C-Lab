/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <string.h>

/*int main()
{
    char a[100]={"Hello "};
    char b[100]={"world"};
    int i,j,len;
    len=strlen(a);
    for(i=len,j=0;b[j];i++,j++){
        a[i]=b[j];
    }
    a[i]=0;
    printf("%s",a);
}*/

/*int main(){
    char a[]="Hello World";
    printf("%s",strupr(a));
}*/

/*int main(){
    char a[]="hello";
    for(int i=0;a[i];i++){
        if(a[i]>'a' && a[i]<'z'){
            a[i]=a[i]-32;
        }
    }
    printf("%s",a);
}*/
/*int main(){
    char a[]="HEllO";
    for(int i=0;a[i];i++){
        if(a[i]>'A' && a[i]<'Z'){
            a[i]=a[i]+32;
        }
    }
    printf("%s",a);
}*/

/*int main(){
    char a[]="HEllO";
    for(int i=0;a[i];i++){
        if(a[i]>'A' && a[i]<'Z'){
            a[i]=a[i]+32;
        }
        else if(a[i]>'a' && a[i]<'z'){
            a[i]=a[i]-32;}
    }
    printf("%s",a);
}*/

int main(){
    char a[]="HEllO&123";
    int c,d,s;
    for(int i=0;a[i];i++){
        if((a[i]>'A' && a[i]<'Z') || (a[i]>'a' && a[i]<'z')){
            c++;
        }
        else if(a[i]>0 && a[i]<9){
            d++;
        }
        else if(a[i]=='!' || a[i]=='@' || a[i]=='#' || a[i]=='$' || a[i]=='%' || a[i]=='^' || a[i]=='&' || a[i]=='*'){
            s++;
        }
    }
    printf("alpha= %d \n digits= %d\n special=%d",c,d,s);
}