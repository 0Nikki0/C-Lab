/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
/*{
    int i,n,s=0;
    scanf("%d",&n);
    int a[n];
    for(i=0;i<n;i++){
        scanf("%d",&a[i]);
    }
    for(i=0;i<n;i++){
        for(int j=0;j<n-i-1;j++){
            if(a[j]>a[j+1]){
                int t=a[j];
                a[j]=a[j+1];
                a[j+1]=t;
            }
        }
    }
    for(i=0;i<n;i++){
        printf("%d",a[i]);
    }
    printf("Min is %d and Max is %d",a[0],a[n-1]);
}*/

/*{
    int i,n;
    scanf("%d",&n);
    int a[n];
    for(i=0;i<n;i++){
        scanf("%d",&a[i]);
    }
    for(i=0;i<n;i++){
        for(int j=0;j<n-i-1;j++){
            if(a[j]>a[j+1]){
                int t=a[j];
                a[j]=a[j+1];
                a[j+1]=t;
            }
        }
    }
    for(i=0;i<n;i++){
        printf("%d\n",a[i]);
    }
    printf("Second Largest Element is %d",a[n-2]);
}*/

/*{
    int i,n,e,o;
    scanf("%d",&n);
    int a[n];
    for(i=0;i<n;i++){
        scanf("%d",&a[i]);
    }
    for(i=0;i<n;i++){
        if(a[i]%2==0){
            e++;
        }
        else{
            o++;
        }
    }
    printf("No. of even elements are %d\nNo. of odd elements are %d",e,o);
}*/

/*{
    int i,n,e;
    scanf("%d",&n);
    int a[n];
    for(i=0;i<n;i++){
        scanf("%d",&a[i]);
    }
    for(i=0;i<n;i++){
        if(a[i]<0){
            e++;
        }
    }
    printf("No. of negative elements are %d",e);
}*/

/*{
    int i,n;
    scanf("%d",&n);
    int a[n];
    for(i=0;i<n;i++){
        scanf("%d",&a[i]);
    }
    int b[n];
    for(i=0;i<n;i++){
        for(int j=0;j=i;j++){
            b[j]=a[i];
        }
    }
    for(i=0;i<n;i++){
        printf("%d",a[i]);
    }
}*/

/*{
    int n;
    printf("Enter length.");
    scanf("%d",&n);
    int a[n],m,pos,k;
    printf("Enter number of elements present in array");
    scanf("%d",&m);
    if(m>=n)
    printf("Insertion not possible");
    else{
        for(int i=0;i<m;i++){
            scanf("%d",&a[i]);
        }
        printf("Enter element and position.");
        scanf("%d%d",&k,&pos);
        for(int i=m-1;i>pos;i++){
            a[i+1]=a[i];
        }
        a[pos]=k;
        m++;
        for(int i=0;i<m;i++){
            printf("%d",a[i]);
        }
    }
    
}*/

/* 10 {
    int n;
    scanf("%d",&n);
    int a[n],m,i,p;
    printf("m");
    scanf("%d",&m);
    if(m==0){
        printf("no element to delete");
    }
    else{
        for(i=0;i<m;i++){
            scanf("%d",&a[i]);
        }
        printf("Position");
        scanf("%d",&p);
        for(i=p;i<m-1;i++){
            a[i+1]=a[i];
        }
        m--;
        for(i=0;i<m;i++){
            printf("%d",a[i]);
        }
    }
}*/



