/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include <math.h>
int sum(int a,int b){
    return (a+b);
}
int cube(int a){
    return(pow(a,3));
}
int dia(int r){
    return (2*r);
}
int cir(int r){
    return (2*3.14*r);
}
int area(int r){
    return (3.14*r*r);
}
int max(int a, int b){
   int k=a>b?a:b;
    return (k);
}
//even odd
int evod(int a){
    int k=a%2==0?0:1;
    return (k);
}
/*int main(){
    int a;
    scanf("%d",&a);
    if(evod(a)==0){
        printf("Even");
    }
    return 0;
}*/

//Prime Number
int prime(int a){
    int c=0;
    for(int i=1;i<a;i++){
        if(a%i==0){
            c++;
        }
    }
    if(c==1){
        printf("Prime Number");
    }
    else{
        printf("Not");
    }
}

/*int main(){
    int a;
    scanf("%d",&a);
    prime(a);
}*/

int arm(int a){
    int c=0,n,r,s=0;
    int temp=a;
    n=a;
    while(a>0){
        a/10==0;
        c++;
    }
    while(a!=0){
        r=n%10;
        s+=pow(r,c);
    }
    if(s==temp){
        printf("Armstrong");
    }
}

/*int main(){
    int a;
    scanf("%d",&a);
    arm(a);
}*/


//array 22
/*int array(int,int *);
int main(){
    int n;
    scanf("%d",&n);
    int a[n],i;
    for(i=0;i<n;i++){
        scanf("%d",&a[i]);
    }
    array(n,a);
}
int array(int n, int *p){
    for(int i=0;i<n;i++){
        printf("%d,",p[i]);
    }
}*/

//array 23
/*int array(int,int *);
int main(){
    int n;
    scanf("%d",&n);
    int a[n],i;
    for(i=0;i<n;i++){
        scanf("%d",&a[i]);
    }
    printf("sum is %d",array(n,a));                                                                                                                                                                                                                                                   array(n,a);
}
int array(int n, int *p){
    int s=0;
    for(int i=0;i<n;i++){
        s+=p[i];
    }
    return(s);
}*/

//array 24
int mm(int,int*);
int main(){
    int n;
    scanf("%d",&n);
    int a[n],i;
    for(i=0;i<n;i++){
        scanf("%d",&a[i]);
    }
    mm(n,a);
    for(int x=0;x<n;x++){
        printf("%d,",a[x]);
    }
}
int mm(int n,int *a){
    for(int i=0;i<n;i++){
        for(int j=0;j<n-i-1;j++){
            if(a[j]>a[j+1]){
                int t=a[j];
                a[j]=a[j+1];
                a[j+1]=t;
            }
        }
    }
    printf("max is %d\n",a[n-1]);
    printf("min is %d",a[0]);
    
}




