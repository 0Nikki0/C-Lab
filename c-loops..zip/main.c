/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

/*int main()
{
    int n,i=1;
    scanf("%d",&n);
    while(i<=n){
        printf("%d\n",i);
        i++;
    }

    return 0;
}*/

/*int main(){
    int i=97;
    while(i<=122){
        printf("%c",i);
        i++;
    }
    return 0;
}*/

/*int main(){
    int n,s=0;
    scanf("%d",&n);
    while(n%10!=0){
        s+=1;
        n/=10;
    }
    printf("%d",s);
    return 0;
}*/

/*int main(){
    int n;
    scanf("%d",&n);
    int l=n%10;
    
    while(n>=10){
        n/=10;
    }
    printf("%d\n",n);
    printf("%d",l);
    return 0;
}*/

/*int main(){
    int n,k=0;
    scanf("%d",&n);
    while(n>0){
        int m=n%10;
        k+=m;
        n/=10;
    }
    printf("%d",k);
    return 0;
}*/

/*int main(){
    int n,k=1;
    scanf("%d",&n);
    while(n>0){
        int m=n%10;
        k*=m;
        n/=10;
    }
    printf("%d",k);
    return 0;
}*/

/*int main(){
    int n,k;
    scanf("%d",&n);
    while(n>0){
        int m=n%10;
        k=k*10+m;
        n/=10;
    }
    printf("%d",k);
    return 0;
}*/

/*int main(){
    int n,k,o;
    scanf("%d",&n);
    o=n;
    while(n>0){
        int m=n%10;
        k=k*10+m;
        n/=10;
    }
    if(k==o){
        printf("Palindrome");
    }
    return 0;
}*/

/*int main(){
    int n,s=0;
    scanf("%d",&n);
    for(int i=1;i<n;i++){
        if(n%i==0){
            s+=1;
        }
    }
    if(s>1){
        printf("not prime");
    }
    else{
        printf("prime");
    }
    return 0;
}*/

/*int main(){
    int n,s;
    scanf("%d",&n);
    for(int i=1;i<=n;i++){
        s=0;
        for(int j=2;j<=i/2;j++){
            if(i%j==0){
                s++;
            }
            break;
        }
        if(s==0 && i!=1){
            printf("%d ",i);
        }
    }
    return 0;
}*/

/*int main(){
    int n,k=0,o;
    scanf("%d",&n);
    o=n;
    while(n>0){
        int m=n%10;
        k+=m*m*m;
        n/=10;
    }
    if(k==o){
        printf("ARmstrong.");
    }
    return 0;
}*/

/*int main(){
    int n,k=0,o;
    scanf("%d",&n);
    while(n>0){
        for(int i=1;i<=n;i++){
            o=i;
            int m=i%10;
            k+=m*m*m;
            i/=10;
            if(o==k){
                printf("%d",i);
            }
        }
    }
    return 0;
}*/

/*int main(){
    int n,i=1,s=0;
    scanf("%d",&n);
    while(i<=n){
        s+=i;
        i++;
        
    }
    printf("%d",s);
}*/

int main(){
    int n;
    scanf("%d",&n);
    int i=1,f=1;
    do{
        f*=i;
        i++;
    }while(i<=n);
    printf("%d",f);
        
}



